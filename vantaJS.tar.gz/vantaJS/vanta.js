VANTA.BIRDS({
  el: "#vanta-bird",
  mouseControls: true,
  touchControls: true,
  gyroControls: false,
  minHeight: 600.00, 
  minWidth: 100.00, 
  scale: 1.00,
  scaleMobile: 1.00
})