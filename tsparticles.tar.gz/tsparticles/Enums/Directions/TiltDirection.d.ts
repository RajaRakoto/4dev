export declare enum TiltDirection {
    clockwise = "clockwise",
    counterClockwise = "counter-clockwise",
    random = "random"
}
export declare type TiltDirectionAlt = "counter-clockwise";
