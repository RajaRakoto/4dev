export declare enum OutModeDirection {
    bottom = "bottom",
    left = "left",
    right = "right",
    top = "top"
}
