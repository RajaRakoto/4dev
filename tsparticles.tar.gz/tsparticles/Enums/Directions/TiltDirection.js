"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TiltDirection = void 0;
var TiltDirection;
(function (TiltDirection) {
    TiltDirection["clockwise"] = "clockwise";
    TiltDirection["counterClockwise"] = "counter-clockwise";
    TiltDirection["random"] = "random";
})(TiltDirection = exports.TiltDirection || (exports.TiltDirection = {}));
