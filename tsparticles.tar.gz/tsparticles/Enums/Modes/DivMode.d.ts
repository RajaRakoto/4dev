export declare enum DivMode {
    bounce = "bounce",
    bubble = "bubble",
    repulse = "repulse"
}
