export declare enum DestroyMode {
    none = "none",
    split = "split"
}
