export declare enum SizeMode {
    precise = "precise",
    percent = "percent"
}
