export declare enum ClickMode {
    attract = "attract",
    bubble = "bubble",
    push = "push",
    remove = "remove",
    repulse = "repulse",
    pause = "pause",
    trail = "trail"
}
