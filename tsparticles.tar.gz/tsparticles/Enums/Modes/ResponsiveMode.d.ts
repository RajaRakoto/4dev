export declare enum ResponsiveMode {
    screen = "screen",
    canvas = "canvas"
}
