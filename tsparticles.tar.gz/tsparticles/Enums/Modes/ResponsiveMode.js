"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponsiveMode = void 0;
var ResponsiveMode;
(function (ResponsiveMode) {
    ResponsiveMode["screen"] = "screen";
    ResponsiveMode["canvas"] = "canvas";
})(ResponsiveMode = exports.ResponsiveMode || (exports.ResponsiveMode = {}));
