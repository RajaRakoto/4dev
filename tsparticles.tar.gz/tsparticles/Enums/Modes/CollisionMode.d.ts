export declare enum CollisionMode {
    absorb = "absorb",
    bounce = "bounce",
    destroy = "destroy"
}
