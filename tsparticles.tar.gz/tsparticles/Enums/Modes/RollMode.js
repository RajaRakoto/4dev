"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RollMode = void 0;
var RollMode;
(function (RollMode) {
    RollMode["both"] = "both";
    RollMode["horizontal"] = "horizontal";
    RollMode["vertical"] = "vertical";
})(RollMode = exports.RollMode || (exports.RollMode = {}));
