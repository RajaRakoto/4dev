export declare enum ThemeMode {
    any = "any",
    dark = "dark",
    light = "light"
}
