export declare enum RollMode {
    both = "both",
    horizontal = "horizontal",
    vertical = "vertical"
}
