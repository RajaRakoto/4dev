export declare enum AnimationStatus {
    increasing = 0,
    decreasing = 1
}
