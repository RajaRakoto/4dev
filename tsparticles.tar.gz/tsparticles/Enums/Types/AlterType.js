"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlterType = void 0;
var AlterType;
(function (AlterType) {
    AlterType["darken"] = "darken";
    AlterType["enlighten"] = "enlighten";
})(AlterType = exports.AlterType || (exports.AlterType = {}));
