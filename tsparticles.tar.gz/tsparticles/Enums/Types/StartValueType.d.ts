export declare enum StartValueType {
    max = "max",
    min = "min",
    random = "random"
}
