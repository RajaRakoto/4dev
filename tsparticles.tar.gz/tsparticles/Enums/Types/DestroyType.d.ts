export declare enum DestroyType {
    none = "none",
    max = "max",
    min = "min"
}
