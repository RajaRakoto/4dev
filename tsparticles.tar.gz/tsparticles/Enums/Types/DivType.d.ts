export declare enum DivType {
    circle = "circle",
    rectangle = "rectangle"
}
