export declare enum OrbitType {
    front = "front",
    back = "back"
}
