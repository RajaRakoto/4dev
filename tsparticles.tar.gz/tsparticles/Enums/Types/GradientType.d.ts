export declare enum GradientType {
    linear = "linear",
    radial = "radial",
    random = "random"
}
