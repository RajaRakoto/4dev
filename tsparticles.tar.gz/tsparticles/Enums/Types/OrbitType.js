"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrbitType = void 0;
var OrbitType;
(function (OrbitType) {
    OrbitType["front"] = "front";
    OrbitType["back"] = "back";
})(OrbitType = exports.OrbitType || (exports.OrbitType = {}));
