export declare enum InteractorType {
    External = 0,
    Particles = 1
}
