"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GradientType = void 0;
var GradientType;
(function (GradientType) {
    GradientType["linear"] = "linear";
    GradientType["radial"] = "radial";
    GradientType["random"] = "random";
})(GradientType = exports.GradientType || (exports.GradientType = {}));
