export declare enum AlterType {
    darken = "darken",
    enlighten = "enlighten"
}
