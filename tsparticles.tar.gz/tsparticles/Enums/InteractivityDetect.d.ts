export declare enum InteractivityDetect {
    canvas = "canvas",
    parent = "parent",
    window = "window"
}
