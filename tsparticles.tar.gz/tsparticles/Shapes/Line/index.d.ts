import type { Main } from "../../main";
export declare function loadLineShape(tsParticles: Main): Promise<void>;
