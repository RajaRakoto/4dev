import type { Main } from "../../main";
export declare function loadCircleShape(tsParticles: Main): Promise<void>;
