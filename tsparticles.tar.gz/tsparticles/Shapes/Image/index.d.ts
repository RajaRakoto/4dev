import type { Main } from "../../main";
export declare function loadImageShape(tsParticles: Main): Promise<void>;
