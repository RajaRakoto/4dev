import type { Main } from "../../main";
export declare function loadTextShape(tsParticles: Main): Promise<void>;
