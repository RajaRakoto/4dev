import type { Main } from "../../main";
export declare function loadStarShape(tsParticles: Main): Promise<void>;
