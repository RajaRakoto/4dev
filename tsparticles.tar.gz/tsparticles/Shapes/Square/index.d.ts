import type { Main } from "../../main";
export declare function loadSquareShape(tsParticles: Main): Promise<void>;
