import type { Main } from "../../main";
export declare function loadGenericPolygonShape(tsParticles: Main): Promise<void>;
export declare function loadTriangleShape(tsParticles: Main): Promise<void>;
export declare function loadPolygonShape(tsParticles: Main): Promise<void>;
