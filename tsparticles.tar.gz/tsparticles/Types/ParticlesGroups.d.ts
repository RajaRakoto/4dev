import type { IParticles } from "../Options/Interfaces/Particles/IParticles";
export declare type ParticlesGroups = {
    [name: string]: IParticles;
};
