export declare type SingleOrMultiple<T> = T | T[];
