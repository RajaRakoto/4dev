export declare type PathOptions = {
    [key: string]: unknown;
};
