import type { IRangeValue } from "../Core/Interfaces/IRangeValue";
export declare type RangeValue = number | IRangeValue;
