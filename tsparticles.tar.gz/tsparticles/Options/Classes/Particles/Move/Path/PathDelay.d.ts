import { ValueWithRandom } from "../../../ValueWithRandom";
export declare class PathDelay extends ValueWithRandom {
    constructor();
}
