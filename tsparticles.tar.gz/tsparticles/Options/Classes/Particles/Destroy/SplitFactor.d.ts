import { ValueWithRandom } from "../../ValueWithRandom";
export declare class SplitFactor extends ValueWithRandom {
    constructor();
}
