import { ValueWithRandom } from "../../ValueWithRandom";
export declare class SplitRate extends ValueWithRandom {
    constructor();
}
