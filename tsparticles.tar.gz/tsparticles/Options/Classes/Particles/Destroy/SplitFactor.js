"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SplitFactor = void 0;
const ValueWithRandom_1 = require("../../ValueWithRandom");
class SplitFactor extends ValueWithRandom_1.ValueWithRandom {
    constructor() {
        super();
        this.value = 3;
    }
}
exports.SplitFactor = SplitFactor;
