import { ValueWithRandom } from "../../ValueWithRandom";
export declare class BounceFactor extends ValueWithRandom {
    constructor();
}
