export interface IMotionReduce {
    factor: number;
    value: boolean;
}
