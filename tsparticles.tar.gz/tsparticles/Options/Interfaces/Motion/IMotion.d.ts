import { IMotionReduce } from "./IMotionReduce";
export interface IMotion {
    disable: boolean;
    reduce: IMotionReduce;
}
