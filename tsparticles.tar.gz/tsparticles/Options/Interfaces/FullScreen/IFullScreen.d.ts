export interface IFullScreen {
    enable: boolean;
    zIndex: number;
}
