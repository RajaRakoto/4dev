export interface IAnimation {
    count: number;
    enable: boolean;
    speed: number;
    sync: boolean;
}
