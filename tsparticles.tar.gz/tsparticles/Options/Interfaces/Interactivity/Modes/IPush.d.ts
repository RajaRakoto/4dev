export interface IPush {
    particles_nb: number;
    default: boolean;
    groups: string[];
    quantity: number;
}
