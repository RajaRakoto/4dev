import { SingleOrMultiple } from "../../../../Types";
export interface IModeDiv {
    ids: SingleOrMultiple<string>;
    selectors: SingleOrMultiple<string>;
}
