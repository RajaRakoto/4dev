export interface IRemove {
    particles_nb: number;
    quantity: number;
}
