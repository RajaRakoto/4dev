export interface ISlow {
    active: boolean;
    radius: number;
    factor: number;
}
