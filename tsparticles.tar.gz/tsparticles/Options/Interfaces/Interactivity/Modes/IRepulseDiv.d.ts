import type { IRepulseBase } from "./IRepulseBase";
import type { IModeDiv } from "./IModeDiv";
export interface IRepulseDiv extends IRepulseBase, IModeDiv {
}
