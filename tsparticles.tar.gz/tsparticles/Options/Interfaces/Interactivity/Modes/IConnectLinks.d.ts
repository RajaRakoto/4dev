export interface IConnectLinks {
    opacity: number;
}
