import type { IGrabLinks } from "./IGrabLinks";
export interface IGrab {
    distance: number;
    line_linked: IGrabLinks;
    lineLinked: IGrabLinks;
    links: IGrabLinks;
}
