export interface IBounce {
    distance: number;
}
