export interface IParallax {
    enable: boolean;
    force: number;
    smooth: number;
}
