export interface ITiltAnimation {
    enable: boolean;
    speed: number;
    sync: boolean;
}
