import type { IDensity } from "./IDensity";
export interface IParticlesNumber {
    max: number;
    density: IDensity;
    limit: number;
    value: number;
}
