export interface IDensity {
    area: number;
    enable: boolean;
    factor: number;
    value_area: number;
}
