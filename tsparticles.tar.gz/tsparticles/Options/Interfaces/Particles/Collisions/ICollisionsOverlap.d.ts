export interface ICollisionsOverlap {
    enable: boolean;
    retries: number;
}
