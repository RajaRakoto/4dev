import { IShapeValues } from "./IShapeValues";
export interface IStarShape extends IShapeValues {
    nb_sides: number;
    sides: number;
    inset: number;
}
