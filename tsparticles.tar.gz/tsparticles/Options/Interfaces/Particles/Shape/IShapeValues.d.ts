export * from "../../../../Core/Interfaces/IShapeValues";
