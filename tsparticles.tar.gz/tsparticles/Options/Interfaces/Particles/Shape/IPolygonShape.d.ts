import type { IShapeValues } from "./IShapeValues";
export interface IPolygonShape extends IShapeValues {
    nb_sides: number;
    sides: number;
}
