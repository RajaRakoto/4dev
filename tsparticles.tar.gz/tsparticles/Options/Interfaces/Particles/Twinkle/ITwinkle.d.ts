import type { ITwinkleValues } from "./ITwinkleValues";
export interface ITwinkle {
    lines: ITwinkleValues;
    particles: ITwinkleValues;
}
