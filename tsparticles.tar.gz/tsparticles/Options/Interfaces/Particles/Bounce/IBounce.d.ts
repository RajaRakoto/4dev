import type { IValueWithRandom } from "../../IValueWithRandom";
export interface IBounce {
    horizontal: IValueWithRandom;
    vertical: IValueWithRandom;
}
