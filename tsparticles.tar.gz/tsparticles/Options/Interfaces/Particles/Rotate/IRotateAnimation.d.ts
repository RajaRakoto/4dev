export interface IRotateAnimation {
    enable: boolean;
    speed: number;
    sync: boolean;
}
