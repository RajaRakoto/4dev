export interface IRollLight {
    enable: boolean;
    value: number;
}
