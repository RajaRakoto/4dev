import type { IValueWithRandom } from "../../IValueWithRandom";
export interface ILifeDuration extends IValueWithRandom {
    sync: boolean;
}
