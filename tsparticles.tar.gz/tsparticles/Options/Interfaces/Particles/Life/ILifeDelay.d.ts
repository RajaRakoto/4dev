import type { IValueWithRandom } from "../../IValueWithRandom";
export interface ILifeDelay extends IValueWithRandom {
    sync: boolean;
}
