export interface IMoveGravity {
    acceleration: number;
    enable: boolean;
    inverse: boolean;
    maxSpeed: number;
}
