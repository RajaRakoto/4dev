export interface IMoveAngle {
    offset: number;
    value: number;
}
