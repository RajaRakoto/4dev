export interface IRandom {
    enable: boolean;
    minimumValue: number;
}
