import type { IColor } from "../../../Core/Interfaces/Colors";
export interface IBackgroundMaskCover {
    color: IColor | string;
    opacity: number;
}
