import type { IColor } from "../../Core/Interfaces";
export declare type IOptionsColor = IColor;
