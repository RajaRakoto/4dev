export interface IDelta {
    value: number;
    factor: number;
}
